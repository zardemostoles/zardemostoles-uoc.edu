
// Import the AWS Amplify modules used in this project:
import Amplify from '@aws-amplify/core';
import API from '@aws-amplify/api';
import awsconfig from '../aws-exports';

// Configure AWS Amplify using defined confg file.
Amplify.configure(awsconfig);

// AWS Amplify Parameters.
// This must be the AWS Amplify name given to the API object.
// This is used from the client hosting to access the URL given to the API Gateway deployed by AWS Amplify.
let apiName = 'smInferenceClient';

// This must be the path you have configured on your API in AWS Amplify
let apiPath = '/api/v1/sagemaker';
let inferenceApiPath = apiPath + '/inference';
let endpointApiPath = apiPath + '/endpoints';

//===============================================
// Get DOM objects
let imgTarget = document.getElementById("inference-image-display");
let imageFileLabel = document.getElementById("image-file-label");
let imageFileSelect = document.getElementById("image-file-select");
imageFileSelect.addEventListener('change', imageSelected, false);

let endpointNameSelect = document.getElementById("endpoint-name-select");
let submit = document.getElementById("submit-inference");
submit.addEventListener('click', submitInference, false);

let inferenceText = document.getElementById("inference-text");

let diagnosticCircle = document.getElementById("diagnostic-circle");

// Var to save submitted inference image before scaling and processing.
let originalImage = new Image();

let predictions = [];
let classCnt = 0;
let classMap = [];

let colorArray = ['red', 'green', 'blue', 'orange', 'pink', 'yellow', 'purple', 'cyan', 'Chartreuse'];

let predictionsReadable = '';
let diagName = 'diag_low';
//===============================================
// Image Related Functions
/**
 * Updates the img display when user selects a test image.
 */
function imageSelected() {

  var fr = new FileReader();
  // when image is loaded, set the src of the image tag
  fr.onload = function (e) {

    // Save submitted inference image into a local var to be sent for inference in original state 
    // before scaling and drawing of bounding boxes. 
    originalImage.src = this.result;

    // Display the submitted image in the UI
    imgTarget.src = originalImage.src;

    // Update the HTML labels with new image
    imageFileLabel.innerHTML = imageFileSelect.files[0].name;
    inferenceText.innerHTML = `Imagen seleccionada: ${imageFileSelect.files[0].name}`;
    
    // Reset diagnostics
    diagnosticCircle.innerHTML = "-- <br> N/D";
    diagnosticCircle.className = "diagnostic diag_none";
    

    // Reset any previous predictions
    predictions = [];
  };

  // fill fr with image data    
  fr.readAsDataURL(imageFileSelect.files[0]);
}

//===============================================
// Sagemaker functions.
/**
 * Validates user inputs and sends the inference request to Sagemaker endpoint
 */
async function submitInference() {

  try {
    //================================================
    // Validate the user inputs:
    validateUserInputs();

    //================================================
    // Remove any spaces from the endpointNameSelect that can happen from copy and paste.
    let epName = endpointNameSelect.value.replace(/ /g, '');

    // Update the text output div
    inferenceText.innerHTML = `Imagen seleccionada: ${imageFileSelect.files[0].name}<br />`;
    inferenceText.innerHTML += `Punto de enlace del sistema de diagnóstico: ${epName}<br />`;

    inferenceText.innerHTML += `Enviando la imagen al sistema de diagnóstico......<br />`;

    // Post the request
    // TODO: If image source is very large can cause long delay, add option to scale image down before POST'ing
    let apiInit = {
      body: {
        endpoint: epName,
        region: 'us-east-1',
        imageBase64: originalImage.src
      }
      // headers: {} // OPTIONAL
    }
    let response = await API.post(apiName, inferenceApiPath, apiInit);

    // if (!response.statusCode) {
    //  throw Error("Ha ocurrido un error en la conexión. Vuelva a intentarlo en unos segundos.")
    //} else if (response.statusCode !== 200) {
    // throw Error(response.error_message);
    //}
    
    while (response.statusCode !== 200) {
    	inferenceText.innerHTML += response.statusCode + ` Enviando la imagen al sistema de diagnóstico......<br />`;
    	response = await API.post(apiName, inferenceApiPath, apiInit);
    }
    

    // if no error, get the predictions and process.
    predictions = response.predictions;

    // Makes prediction vaues more readable and display to UI
    //inferenceText.innerHTML += getPredictionHtmlPrettyPrint();
    //applyPredictionsToImage();
    inferenceText.innerHTML += "Resultado: " + predictions;
    // Diagnostic as human readable %
    predictionsReadable = `${Math.round(predictions * 100)} `;
    diagnosticCircle.innerHTML = predictionsReadable;
    
    switch (true) {
    	case (predictions < 0.25):
    		diagName = 'diag_low';
    		diagnosticCircle.innerHTML += "<br> BAJO";
    		break;
    	case (predictions < 0.5):
    		diagName = 'diag_med';
    		diagnosticCircle.innerHTML += "<br> MEDIO"; 
    		break;
    	case (predictions < 0.75):
    		diagName = 'diag_high';
    		diagnosticCircle.innerHTML += "<br> ALTO";
    		break;
    	default:
    		diagName = 'diag_very_high';
    		diagnosticCircle.innerHTML += "<br> MUY ALTO";
    		break;	
   			
    }
    
    diagnosticCircle.className = "diagnostic " + diagName

  } catch (err) {
    inferenceText.innerHTML += `ERROR: Ha ocurrido un error:<br />${err}`;
    console.log(err, err.stack);
  }
}

async function setSagemakerEndpoints() {

  try {
    // Post the request
    let apiInit = {
      body : {
      region: 'us-east-1'
      }
    }
    let response = await API.post(apiName, endpointApiPath, apiInit);

    if (!response.statusCode) {
      throw Error("Ha ocurrido un error desconocido")
    } else if (response.statusCode !== 200) {
      throw Error(response.error_message);
    }

    let endpoints = response.result;
    var options = endpoints.map(function (endpoint) {
      let epName = endpoint.EndpointName;
      return `<option value=${epName}>${epName}</option>`
    });

    endpointNameSelect.innerHTML = options;

  } catch (err) {
    inferenceText.innerHTML += `ERROR: Error en la búsqueda de puntos de enlace de SageMaker:<br />${err}`;
    console.log(err, err.stack);
  }
}

function validateUserInputs() {

  // Test user has selected an image
  if (imageFileSelect.files[0] === undefined) {
    throw Error('No se ha seleccionado imagen.');
  };

  // Test an Endpoint was entered.
  if (endpointNameSelect.value === undefined || endpointNameSelect.value.length < 1) {
    throw Error('No Sagemaker Inference Endpoint has been entered.');
  };
}

// Takes Amazon Sagemaker inference endpoint predictions and updates bounding boxed to imgTarget
function applyPredictionsToImage() {

  let threshold = (thresholdSlider.value / 100);
  let width = imgTarget.width;
  let height = imgTarget.height;

  // Create the trace canvas to draw on image
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  ctx.drawImage(originalImage, 0, 0, width, height);
  ctx.lineWidth = 2;
  ctx.font = "15px Arial";

  ctx.beginPath();
  let x1, x2, y1, y2;
  let labelText, classVal, confidence, color;
  for (let i = 0; i < predictions.length; i++) {
    if (predictions[i][1] > threshold) {

      classVal = predictions[i][0];
      color = colorArray[predictions[i][0]];

      // Set color as per class label index of colorArray and 
      ctx.strokeStyle = color;

      // Get X/Y points from prediction.
      x1 = predictions[i][2] * width;
      y1 = predictions[i][3] * height;
      x2 = (predictions[i][4] * width) - x1;
      y2 = (predictions[i][5] * height) - y1;

      // Draw the box for detections.
      ctx.rect(x1, y1, x2, y2);
      ctx.stroke();

      // Draw the label and confidence as text
      confidence = `${Math.round(predictions[i][1] * 10000) / 100} %`;
      labelText = `ID:${i + 1}-${getPredictionLabel(classVal)} - ${confidence}`;

      ctx.fillStyle = color;
      ctx.fillText(labelText, x1, y1 - 2);

    }
  }

  let url = canvas.toDataURL();
  imgTarget.src = url;
}

function thresholdUpdate() {
  let val = thresholdSlider.value;
  thresholdLabel.innerHTML = `Confidence Threshold: ${val}%`;
  if (predictions && predictions.length > 0) applyPredictionsToImage()
}

//===============================================
// Add / remove to Inference Class list inputs.
function addClassInput() {
  if (classCnt >= 9) {
    alert('Reached maximum supported inference classes');
    return;
  }

  classCnt = classCnt + 1;

  let classInput = [];
  classInput.push(`          <div class="row" id="inference-class-${classCnt}-row">\n`);
  classInput.push(`            <div class="col input-group input-group-sm mb-1">\n`);
  classInput.push(`              <div class="input-group-prepend">\n`);
  classInput.push(`                <span class="input-group-text" id="inference-class-${classCnt}-label">Class ${classCnt}:</span>\n`);
  classInput.push(`              </div>\n`);
  classInput.push(`              <input type="text" class="form-control" id="inference-class-${classCnt}" placeholder="Enter Inference Class ${classCnt}" aria-label="Inference Class ${classCnt}" aria-describedby="inference-class-${classCnt}-label">\n`);
  classInput.push(`            </div>\n`);
  classInput.push(`          </div>\n`);

  let html = classInput.join("");
  $(html).insertBefore($("#inference-class-add-remove"));
}

// Remove class list.
function removeClassInput() {
  if (classCnt < 0) {
    alert('No inference classes available for delete.');
    return;
  }
  if ($(`#inference-class-${classCnt}-row`).remove()) classCnt -= 1;

}

//===============================================
// Helper classes

// Take a prediction array in order: [label Index, confidence, xmin, ymin, xmax, ymax]
// and return human readable response
function getPredictionHtmlPrettyPrint() {

  // Loop through all element in predictions and round to 4 places.
  let response = [];
  let classVal, classLabel = "", confidence = "", color = "";
  for (let i = 0; i < predictions.length; i++) {

    // Set the class label as per Class Map if user entered a matching vakue
    classVal = parseInt(predictions[i][0]);

    // Prediction confidence as human readable %
    confidence = `${Math.round(predictions[i][1] * 10000) / 100} %`;

    // Get the prediction color to be dicplayed for this label
    color = colorArray[classVal];

    // Get the class label.
    classLabel = getPredictionLabel(classVal);

    // Now append to response
    response.push(`<p style="color: ${color}">${i + 1} - ${classLabel} - Confidence: ${confidence}</p>`);

  }

  return response.join("");
}

function getPredictionLabel(classVal) {

  // If a matching value in classMap the set as label - if not, return unknown-label
  let classLabel;
  if (classMap[classVal] && classMap[classVal].length >= 0) {
    classLabel = classMap[classVal];
  } else {
    classLabel = `label:${classVal}`;
  }

  return classLabel;
}

// Set Sagemaker endpoint

setSagemakerEndpoints();
